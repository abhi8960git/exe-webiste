export {default as Event} from "./EventsCard/Event";
export {default as Card} from "./Card";

export {default as Workshop} from  "./WorkshopCard/Event";

export {default as Contact} from "./Contact";
export {default as MemberCard} from "./MemberCard/MemberCard";