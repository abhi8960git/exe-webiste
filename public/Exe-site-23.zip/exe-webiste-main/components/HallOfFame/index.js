import React from 'react'

const HallOfFame
 = () => {
  return (
    <div>HallOfFame
        
    </div>
  )
}

export default HallOfFame
